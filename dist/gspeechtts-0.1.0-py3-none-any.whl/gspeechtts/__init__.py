from .core import GSpeechTTS

__all__ = ["GSpeechTTS"]
